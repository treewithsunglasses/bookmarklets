// open options page then close popup.
chrome.runtime.openOptionsPage(function(){
  window.close();
})